El README.md canónico ya está publicado en https://github.com/papayaykware/GCD-EDU. Se conserva fuera de este paquete para evitar sobrescribir el documento existente.

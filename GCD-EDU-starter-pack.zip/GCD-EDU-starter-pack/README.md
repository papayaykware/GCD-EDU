# GCD-EDU — starter implementation

This directory contains the executable starter components for the GCD-EDU repository.

**Canonical project README:** https://github.com/papayaykware/GCD-EDU

The upstream repository already contains the main `README.md` and `License.md`.
When integrating this package into that repository, preserve those existing files;
this package README exists so that the Python package can be built and tested standalone.

## Quick start

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\\Scripts\\Activate.ps1

python -m pip install -e ".[dev]"
python -m pytest
python -m pip install -e ".[notebooks]"
jupyter notebook notebooks/04_baseline_comparison.ipynb
```

Run a comparison from the repository root:

```bash
gcd-edu-simulate --replicates 200 --steps 30 --seed 20261015
```

The simulator uses synthetic learners only. Its results test code paths and demonstrate
a simulation workflow; they do not establish real-world educational efficacy.
See `docs/experimental_notes.md` for the assumptions and limitations.

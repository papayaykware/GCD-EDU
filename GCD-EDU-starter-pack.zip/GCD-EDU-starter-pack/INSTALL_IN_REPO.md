# Cómo integrar este paquete en el repositorio existente

El repositorio ya contiene `README.md` y `License.md`. Para evitar sobrescribir
el documento publicado o cambiar su licencia accidentalmente, copia el resto de
los archivos de este paquete a la raíz del repositorio y conserva esos dos archivos.

## Pasos

1. Descomprime el paquete localmente.
2. Copia `pyproject.toml`, `CITATION.cff`, `requirements.txt`, `.gitignore` y las
   carpetas `src/`, `tests/`, `notebooks/`, `configs/`, `docs/`, `.github/`, `results/`.
3. En `pyproject.toml`, confirma que `license-files = ["License.md"]` coincide con
   el nombre exacto de la licencia que ya está en el repositorio.
4. Ejecuta las pruebas y el notebook siguiendo el README de instalación.
5. Revisa los metadatos de `CITATION.cff` antes de publicar una versión etiquetada.

Este paquete no modifica directamente GitHub ni crea commits. Los archivos deben
incorporarse mediante Git, GitHub web o un cliente Git autorizado.
